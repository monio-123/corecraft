import{z as r}from"./vendor-core-BM2cXDBx.js";async function c(t){try{return await r.confirm(`你确认要${t}么？`,t,{confirmButtonText:"确认",cancelButtonText:"取消"}),!0}catch{return!1}}export{c};
