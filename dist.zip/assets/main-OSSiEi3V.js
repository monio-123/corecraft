import{d as r,r as o}from"./bootstrap-DcVWvRO5.js";import"./vendor-core-BNv24AsY.js";r(o);
