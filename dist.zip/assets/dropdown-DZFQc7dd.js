import{b as r}from"./vendor-core-BM2cXDBx.js";function u(){const o=r(!1);function e(n){n&&(o.value=!0)}return{keepMounted:o,onDropdownShow:e}}export{u};
