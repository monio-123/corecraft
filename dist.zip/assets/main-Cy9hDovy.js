import{d as r,r as o}from"./bootstrap-CGagDfRx.js";import"./vendor-core-D5OYEFEj.js";r(o);
