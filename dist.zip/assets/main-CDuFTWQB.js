import{d as r,r as o}from"./bootstrap-V9LLCmnY.js";import"./vendor-core-BM2cXDBx.js";r(o);
