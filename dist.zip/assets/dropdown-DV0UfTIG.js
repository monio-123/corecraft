import{r}from"./vendor-core-KLT20Xze.js";function u(){const o=r(!1);function e(n){n&&(o.value=!0)}return{keepMounted:o,onDropdownShow:e}}export{u};
