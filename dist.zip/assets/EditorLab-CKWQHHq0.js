import{r as s,d as r,e as a,i as w,y as v,f as m,g as c,b as M,F as E,A as V,p as D,B as I,C as N,D as J,t as b,o as d,h as f,E as R,G as z}from"./vendor-core-KLT20Xze.js";import{_ as O,c as q}from"./MilkdownEditor-BLj0fgcv.js";import{T as A}from"./TopicOutline--Fg3ZMGz.js";import{t as H}from"./categoryTree-DW4M6BJM.js";import{_ as K}from"./bootstrap-DOpRJS_0.js";import"./KbSvgIcon-DPw-9qix.js";import"./KbTooltip-CRA2YRpD.js";import"./categoryNav-Cqc5nXlk.js";import"./routeQuery-BLy0RPAv.js";import"./searchMode-MHtkyhlk.js";const B={class:"lab"},G={class:"lab__bar"},P={class:"lab__presets"},$={class:"lab__out"},j={class:"lab__outHead"},Q={key:0,class:"lab__outline"},F={class:"lab__checkTitle"},U={key:0},Z=Object.assign({name:"EditorLab"},{__name:"EditorLab",setup(W){const y=H([{id:48,name:"语言",parentId:0},{id:1,name:"java",parentId:48},{id:53,name:"基础",parentId:1},{id:6,name:"集合",parentId:53},{id:58,name:"List",parentId:6},{id:59,name:"Set",parentId:6},{id:60,name:"Map",parentId:6},{id:2,name:"计算机网络",parentId:0}]),k=[{id:"plain",name:"纯文本",md:`集合分为两大分支：Collection 与 Map。

Collection 又分为 List 和 Set。`},{id:"heading",name:"标题层级",md:`# 一级标题

## 二级标题

正文一段。

### 三级标题

再一段。

## 第二个二级

结尾。`},{id:"bold-list",name:"列表 + 粗体",md:`Collection派生了三个子接口：

- **List:** List代表了有序可重复集合，可直接根据元素的索引来访问
- **Set:** Set代表无序不可重复集合，只能根据元素本身来访问
- **Queue:** Queue是队列集合`},{id:"bold-list-tight",name:"粗体紧跟文字（无空格）",md:`- **List：**List代表了有序可重复集合
- **Set：**Set代表无序不可重复集合`},{id:"link",name:"链接",md:`正文里带一个普通链接：

[MDN](https://developer.mozilla.org)

带一个目录引用：

见 [List](/app/learn?category=58)`},{id:"file",name:"附件",md:`带三个附件：

[天源迪科-电渠资源台账.xlsx](/api/files/u/6/contents/abc123/天源迪科-电渠资源台账.xlsx)

[说明文档.md](/api/files/u/6/contents/abc123/说明文档.md)

[报告.pdf](/api/files/u/6/contents/abc123/报告.pdf)

普通链接不受影响：[MDN](https://developer.mozilla.org)`},{id:"table",name:"表格",md:`| 集合 | 有序 | 可重复 |
| --- | --- | --- |
| List | 是 | 是 |
| Set | 否 | 否 |`},{id:"code",name:"代码块",md:"```java\nList<String> list = new ArrayList<>();\n```"},{id:"kbfig-all",name:"kbfig v2 全图型 (10 种)",md:["### 1. 层级树（tree）",'```kbfig\n{"type":"tree","title":"集合框架接口层次","root":{"t":"集合框架接口","tag":"两大体系","children":[{"t":"Collection","d":"单列数据根接口","children":[{"t":"List","d":"有序、可重复"},{"t":"Set","d":"无序、不可重复","tag":"SortedSet"},{"t":"Queue","d":"先进先出队列","tag":"Deque"}]},{"t":"Map","d":"键值对根接口","children":[{"t":"SortedMap","d":"按键排序","tag":"NavigableMap"}]}]}}\n```',"### 2. 自由拓扑（graph）",'```kbfig\n{"type":"graph","title":"ConcurrentHashMap putVal 写入分支","dir":"LR","nodes":[{"id":"a","label":"putVal 写入","kind":"step"},{"id":"b","label":"table 已初始化?","kind":"decision"},{"id":"c","label":"initTable CAS 立表","kind":"step"},{"id":"d","label":"目标桶为空?","kind":"decision"},{"id":"e","label":"casTabAt 无锁写入","kind":"step","hl":"ok"},{"id":"f","label":"桶头 hash 态","kind":"decision"},{"id":"g","label":"helpTransfer 协助扩容","kind":"step"},{"id":"h","label":"synchronized 锁头","sub":"链表 / 红黑树插入","kind":"step","hl":"warn"}],"edges":[{"from":"a","to":"b"},{"from":"b","to":"c","label":"否"},{"from":"b","to":"d","label":"是","hl":"ok"},{"from":"d","to":"e","label":"是","hl":"ok"},{"from":"d","to":"f","label":"否"},{"from":"f","to":"g","label":"MOVED","style":"dashed"},{"from":"f","to":"h","label":"正常","hl":"primary"}]}\n```',"### 3. 短步横排（stages）",'```kbfig\n{"type":"stages","title":"HashMap 扩容与 rehash 流程","steps":[{"t":"触发判定","d":"size > threshold"},{"t":"申请新数组","d":"容量翻倍","hl":true},{"t":"逐桶拆分","d":"hash & oldCap"},{"t":"回填新表","d":"低位原下标"},{"t":"更新阈值","d":"newCap × factor"}],"loop":"注：Java 8 尾插保持原链顺序"}\n```',"### 4. 内存槽位（memory）",'```kbfig\n{"type":"memory","title":"HashMap 桶数组 + 链表 + 红黑树挂载图","stack":[{"name":"map 引用","ref":"0x7f3a → 堆实例"}],"container":{"name":"堆内存 · Node<K,V>[] table","slots":[{"index":0,"val":"null"},{"index":1,"val":"桶位链表头","hl":"warn","chain":[{"t":"Node K1","d":"next → 下一节点"},{"t":"Node K2","d":"next → null"}]},{"index":2,"val":"红黑树根","hl":"ok","tree":{"root":"Root","left":"T1","right":"T2","note":"链表 ≥ 8 且容量 ≥ 64 时树化"}}]}} \n```',"### 5. 时序交互（sequence）",'```kbfig\n{"type":"sequence","title":"BlockingQueue put / take 阻塞与唤醒","participants":[{"id":"p","name":"生产者"},{"id":"q","name":"阻塞队列","hl":true},{"id":"c","name":"消费者"}],"messages":[{"from":"p","to":"q","text":"1. put(e) 队列已满","kind":"sync"},{"from":"q","to":"p","text":"2. 挂起等待 notFull","kind":"wait"},{"from":"c","to":"q","text":"3. take() 腾出空位","kind":"sync"},{"from":"q","to":"p","text":"4. signal() 唤醒","kind":"ok"}]}\n```',"### 6. 演进里程碑（timeline）",'```kbfig\n{"type":"timeline","title":"Java 演进（8 → 11 → 17 → 21）","events":[{"tag":"JDK 8","t":"Lambda 与 Stream","d":"函数式编程落地"},{"tag":"JDK 11 LTS","t":"var 与 HttpClient","d":"ZGC 实验"},{"tag":"JDK 17 LTS","t":"Sealed 与 Record","d":"代数数据类型"},{"tag":"JDK 21 LTS","t":"虚拟线程转正","d":"分代 ZGC","hl":true}]}\n```',"### 7. 核心拆解（anatomy）",'```kbfig\n{"type":"anatomy","title":"Java 数组对象构成","center":{"t":"数组对象实例","tag":"堆内存连续区","d":"int[] b = {5, 2, 8}"},"parts":[{"t":"栈上引用 b","d":"只存堆首地址"},{"t":"对象头 Header","d":"MarkWord + 类型指针"},{"t":"只读字段 length","d":"固定不变 = 3","hl":true},{"t":"连续槽位 b[0..2]","d":"O(1) 寻址读取"}]}\n```',"### 8. 多维对比（matrix）",'```kbfig\n{"type":"matrix","title":"Java 方法参数传递三种情形","cols":["形参重赋值","改对象属性","实参影响"],"rows":[{"name":"基本类型","cells":["改值副本","无对象","不受影响"]},{"name":"可变对象","cells":["改引用副本","改同一实例","变化可见"]},{"name":"String","cells":["改引用副本","final 不可变","不受影响"]}]}\n```',"### 9. 分层包含（layers）",'```kbfig\n{"type":"layers","title":"JVM 运行时数据区","groups":[{"name":"线程私有","note":"随线程生灭","items":[{"t":"程序计数器","d":"字节码行号"}]},{"name":"线程共享","note":"全进程一份","items":[{"t":"Java 堆","d":"GC 主战场","tags":["Eden 8","S0 1","S1 1","Old"]}]}]}\n```',"### 10. 一一对应（pairs）",'```kbfig\n{"type":"pairs","title":"SOLID 五原则","left":"原则","right":"解决的问题","rows":[{"l":"单一职责","r":"一个类只有一个变化理由"},{"l":"开闭原则","r":"加需求靠新增，不改已有代码"}]}\n```'].join(`

`)}],S=k.find(t=>t.id===new URLSearchParams(window.location.search).get("preset"))||k[0],l=s(S.md),p=s(!0),u=s(0),i=s(null),g=s([]),h=s(null);function x(t){var e;(e=h.value)==null||e.scrollToHeading(t)}function C(t){l.value=t.md,u.value++,i.value=null}async function _(){for(let t=0;t<40;t++)await z(),await new Promise(e=>setTimeout(e,50))}async function L(){const t=l.value;u.value++,await _();const e=l.value;u.value++,await _();const o=l.value;if(e===o){i.value={ok:!0,detail:""};return}i.value={ok:!1,detail:[`【第一次存下来的】
${t}`,`【重新打开后再存】
${e}`,`【再打开一次】
${o}`].join(`

`)}}async function T(){await q(l.value)&&R.success("已复制")}return(t,e)=>{const o=M("el-button");return d(),r("div",B,[a("header",G,[e[4]||(e[4]=a("h1",null,"编辑器实验台",-1)),e[5]||(e[5]=a("span",{class:"lab__note"},"编辑器行为的自测页：改完编辑器相关功能来这里跑一遍。免登录、不落库。",-1)),m(o,{size:"small",onClick:e[0]||(e[0]=n=>p.value=!p.value)},{default:c(()=>[f(b(p.value?"简洁模式":"完整模式"),1)]),_:1})]),a("section",P,[e[6]||(e[6]=a("span",{class:"lab__label"},"预设内容",-1)),(d(),r(E,null,V(k,n=>m(o,{key:n.id,size:"small",text:"",onClick:Y=>C(n)},{default:c(()=>[f(b(n.name),1)]),_:2},1032,["onClick"])),64))]),(d(),w(O,{key:u.value,ref_key:"editorRef",ref:h,modelValue:l.value,"onUpdate:modelValue":e[1]||(e[1]=n=>l.value=n),"show-toolbar":p.value,"category-tree":D(y),onOutline:e[2]||(e[2]=n=>g.value=n)},null,8,["modelValue","show-toolbar","category-tree"])),a("section",$,[a("div",j,[e[9]||(e[9]=a("span",{class:"lab__label"},"存下来的 markdown",-1)),m(o,{size:"small",text:"",onClick:L},{default:c(()=>[...e[7]||(e[7]=[f("往返自检",-1)])]),_:1}),m(o,{size:"small",text:"",onClick:T},{default:c(()=>[...e[8]||(e[8]=[f("复制",-1)])]),_:1})]),I(a("textarea",{"onUpdate:modelValue":e[3]||(e[3]=n=>l.value=n),class:"lab__ta",spellcheck:"false"},null,512),[[N,l.value]])]),g.value.length?(d(),r("section",Q,[e[10]||(e[10]=a("div",{class:"lab__label"},"大纲（点一条跳过去；鼠标移上去有工具条；标题左边的箭头折的是大纲自己那一支）",-1)),m(A,{items:g.value,onNavigate:x},null,8,["items"])])):v("",!0),i.value?(d(),r("section",{key:1,class:J(["lab__check kb-verdict",i.value.ok?"is-good":"is-bad"])},[a("p",F,b(i.value.ok?"往返稳定":"往返不稳定 —— 这就是刷新后走样的那种内容"),1),i.value.ok?v("",!0):(d(),r("pre",U,b(i.value.detail),1))],2)):v("",!0)])}}}),me=K(Z,[["__scopeId","data-v-85633cce"]]);export{me as default};
