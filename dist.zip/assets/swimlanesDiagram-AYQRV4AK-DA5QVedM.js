import{c as r,s as e}from"./flowDiagram-IUGLLWBU-CtpxicgH.js";import{_ as o}from"./mermaid.core-DSU_XdCQ.js";import"./vendor-core-BM2cXDBx.js";import"./chunk-5VM5RSS4-BkguT4zh.js";import"./chunk-XXDRQBXY-BSOS8NbF.js";import"./chunk-VQ5W62QI-DHFhygc4.js";import"./chunk-55XCU76K-B4YhRw-q.js";import"./channel-iGIFPw0r.js";import"./bootstrap-V9LLCmnY.js";var a=o(t=>`${e(t)}
  .swimlane.cluster:not([data-color-id]) rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),m=a,y=r({styles:m});export{y as diagram};
