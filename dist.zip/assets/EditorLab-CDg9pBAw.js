import{i,b as d,e as n,q as T,p as L,f as m,g as p,h as x,F as A,n as M,j as V,l as D,M as B,y as h,t as v,o as r,v as b,E as j,N as O}from"./vendor-core-BNv24AsY.js";import{_ as R,c as N}from"./MilkdownEditor-sYyohgBd.js";import{T as z}from"./TopicOutline-Dt8vS7A8.js";import{t as P}from"./categoryTree-DU55SVNf.js";import{_ as $}from"./bootstrap-DcVWvRO5.js";import"./KbSvgIcon-CSPOBPCU.js";import"./KbTooltip-C0skPIgj.js";import"./categoryNav-CbdfYr1q.js";import"./viewPref-OqQoTdi6.js";import"./routeQuery-C1oXYsrp.js";import"./searchMode-CAFp6cP8.js";const F={class:"lab"},J={class:"lab__bar"},H={class:"lab__presets"},U={class:"lab__out"},G={class:"lab__outHead"},Q={key:0,class:"lab__outline"},W={class:"lab__checkTitle"},q={key:0},K=Object.assign({name:"EditorLab"},{__name:"EditorLab",setup(X){const g=P([{id:48,name:"语言",parentId:0},{id:1,name:"java",parentId:48},{id:53,name:"基础",parentId:1},{id:6,name:"集合",parentId:53},{id:58,name:"List",parentId:6},{id:59,name:"Set",parentId:6},{id:60,name:"Map",parentId:6},{id:2,name:"计算机网络",parentId:0}]),_=[{id:"plain",name:"纯文本",md:`集合分为两大分支：Collection 与 Map。

Collection 又分为 List 和 Set。`},{id:"heading",name:"标题层级",md:`# 一级标题

## 二级标题

正文一段。

### 三级标题

再一段。

## 第二个二级

结尾。`},{id:"bold-list",name:"列表 + 粗体",md:`Collection派生了三个子接口：

- **List:** List代表了有序可重复集合，可直接根据元素的索引来访问
- **Set:** Set代表无序不可重复集合，只能根据元素本身来访问
- **Queue:** Queue是队列集合`},{id:"bold-list-tight",name:"粗体紧跟文字（无空格）",md:`- **List：**List代表了有序可重复集合
- **Set：**Set代表无序不可重复集合`},{id:"link",name:"链接",md:`正文里带一个普通链接：

[MDN](https://developer.mozilla.org)

带一个目录引用：

见 [List](/app/learn?category=58)`},{id:"table",name:"表格",md:`| 集合 | 有序 | 可重复 |
| --- | --- | --- |
| List | 是 | 是 |
| Set | 否 | 否 |`},{id:"code",name:"代码块",md:"```java\nList<String> list = new ArrayList<>();\n```"},{id:"mermaid",name:"mermaid 图",md:`字节码与跨平台机制：

\`\`\`mermaid
graph LR
    A[Java 源文件 .java] -->|javac 编译| B[字节码 .class]
    B -->|JVM on Windows| C[Windows 运行]
    B -->|JVM on Linux| D[Linux 运行]
    B -->|JVM on macOS| E[macOS 运行]
\`\`\`

图下面就是源码，可以直接改。`},{id:"mermaid-class",name:"mermaid 类图",md:`集合框架里 List 的位置：

\`\`\`mermaid
classDiagram
    class Iterable["Iterable（迭代器）"] {
        <<interface>>
    }
    class Collection["Collection（单列集合）"] {
        <<interface>>
    }
    class List["List（有序,可重复）"] {
        <<interface>>
        +add(E e) boolean
        +remove(Object o) boolean
    }
    class ArrayList["ArrayList（数组实现）"]
    class LinkedList["LinkedList（链表实现）"]
    Iterable <|-- Collection : 继承
    Collection <|-- List : 继承
    List <|.. ArrayList : 实现
    List <|.. LinkedList : 实现
    classDef iface fill:#F8D7DA,stroke:#C77C8A,color:#2b2b2b
    classDef impl fill:#D6E4F7,stroke:#6C8EBF,color:#2b2b2b
    cssClass "Iterable,Collection,List" iface
    cssClass "ArrayList,LinkedList" impl
\`\`\`

图下面就是源码，可以直接改。`}],y=_.find(a=>a.id===new URLSearchParams(window.location.search).get("preset"))||_[0],s=i(y.md),c=i(!0),u=i(0),l=i(null),f=i([]),k=i(null);function E(a){var e;(e=k.value)==null||e.scrollToHeading(a)}function S(a){s.value=a.md,u.value++,l.value=null}async function C(){for(let a=0;a<40;a++)await O(),await new Promise(e=>setTimeout(e,50))}async function w(){const a=s.value;u.value++,await C();const e=s.value;u.value++,await C();const o=s.value;if(e===o){l.value={ok:!0,detail:""};return}l.value={ok:!1,detail:[`【第一次存下来的】
${a}`,`【重新打开后再存】
${e}`,`【再打开一次】
${o}`].join(`

`)}}async function I(){await N(s.value)&&j.success("已复制")}return(a,e)=>{const o=x("el-button");return r(),d("div",F,[n("header",J,[e[4]||(e[4]=n("h1",null,"编辑器实验台",-1)),e[5]||(e[5]=n("span",{class:"lab__note"},"编辑器行为的自测页：改完编辑器相关功能来这里跑一遍。免登录、不落库。",-1)),m(o,{size:"small",onClick:e[0]||(e[0]=t=>c.value=!c.value)},{default:p(()=>[b(v(c.value?"简洁模式":"完整模式"),1)]),_:1})]),n("section",H,[e[6]||(e[6]=n("span",{class:"lab__label"},"预设内容",-1)),(r(),d(A,null,M(_,t=>m(o,{key:t.id,size:"small",text:"",onClick:Z=>S(t)},{default:p(()=>[b(v(t.name),1)]),_:2},1032,["onClick"])),64))]),(r(),T(R,{key:u.value,ref_key:"editorRef",ref:k,modelValue:s.value,"onUpdate:modelValue":e[1]||(e[1]=t=>s.value=t),"show-toolbar":c.value,"category-tree":V(g),onOutline:e[2]||(e[2]=t=>f.value=t)},null,8,["modelValue","show-toolbar","category-tree"])),n("section",U,[n("div",G,[e[9]||(e[9]=n("span",{class:"lab__label"},"存下来的 markdown",-1)),m(o,{size:"small",text:"",onClick:w},{default:p(()=>[...e[7]||(e[7]=[b("往返自检",-1)])]),_:1}),m(o,{size:"small",text:"",onClick:I},{default:p(()=>[...e[8]||(e[8]=[b("复制",-1)])]),_:1})]),D(n("textarea",{"onUpdate:modelValue":e[3]||(e[3]=t=>s.value=t),class:"lab__ta",spellcheck:"false"},null,512),[[B,s.value]])]),f.value.length?(r(),d("section",Q,[e[10]||(e[10]=n("div",{class:"lab__label"},"大纲（点一条跳过去；鼠标移上去有工具条；标题左边的箭头折的是大纲自己那一支）",-1)),m(z,{items:f.value,onNavigate:E},null,8,["items"])])):L("",!0),l.value?(r(),d("section",{key:1,class:h(["lab__check kb-verdict",l.value.ok?"is-good":"is-bad"])},[n("p",W,v(l.value.ok?"往返稳定":"往返不稳定 —— 这就是刷新后走样的那种内容"),1),l.value.ok?L("",!0):(r(),d("pre",q,v(l.value.detail),1))],2)):L("",!0)])}}}),ce=$(K,[["__scopeId","data-v-4ab8f9a8"]]);export{ce as default};
