import{c as r,s as e}from"./flowDiagram-IUGLLWBU-BYcZ3PPB.js";import{_ as o}from"./mermaid.core-BuiQHdJY.js";import"./vendor-core-D5OYEFEj.js";import"./chunk-5VM5RSS4-BdTIN866.js";import"./chunk-XXDRQBXY-VPEhVic3.js";import"./chunk-VQ5W62QI-BgxWqy1u.js";import"./chunk-55XCU76K-CvEaYwPH.js";import"./channel-CCp9wx4t.js";import"./bootstrap-CGagDfRx.js";var a=o(t=>`${e(t)}
  .swimlane.cluster:not([data-color-id]) rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),m=a,y=r({styles:m});export{y as diagram};
