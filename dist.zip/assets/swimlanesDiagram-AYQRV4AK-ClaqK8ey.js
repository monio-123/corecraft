import{c as r,s as e}from"./flowDiagram-IUGLLWBU-CPCAnJjZ.js";import{_ as o}from"./mermaid.core-DF5KPFME.js";import"./vendor-core-BNv24AsY.js";import"./chunk-5VM5RSS4-DfbThBTi.js";import"./chunk-XXDRQBXY-DkTDzQXK.js";import"./chunk-VQ5W62QI-BCfp5yPb.js";import"./chunk-55XCU76K-BX8074ip.js";import"./channel-BZkNA550.js";import"./bootstrap-DcVWvRO5.js";var a=o(t=>`${e(t)}
  .swimlane.cluster:not([data-color-id]) rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),m=a,y=r({styles:m});export{y as diagram};
