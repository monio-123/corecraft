import{b as i,d,f as a,q as I,p as L,g as c,h as p,i as T,F as M,n as A,j as D,l as V,M as h,y as B,t as v,o as r,v as b,E as j,N}from"./vendor-core-BM2cXDBx.js";import{_ as O,c as R}from"./MilkdownEditor-BEzadIFO.js";import{T as z}from"./TopicOutline-Bu8BB4lV.js";import{t as P}from"./categoryTree-DU55SVNf.js";import{_ as $}from"./bootstrap-V9LLCmnY.js";import"./KbSvgIcon-m3_yxMgU.js";import"./KbTooltip-CyS3Ms0e.js";import"./categoryNav-BAcyoUbT.js";import"./viewPref-DwKIwgB9.js";import"./routeQuery-C1oXYsrp.js";import"./searchMode-CAFp6cP8.js";const F={class:"lab"},J={class:"lab__bar"},H={class:"lab__presets"},U={class:"lab__out"},G={class:"lab__outHead"},Q={key:0,class:"lab__outline"},W={class:"lab__checkTitle"},q={key:0},K=Object.assign({name:"EditorLab"},{__name:"EditorLab",setup(X){const g=P([{id:48,name:"语言",parentId:0},{id:1,name:"java",parentId:48},{id:53,name:"基础",parentId:1},{id:6,name:"集合",parentId:53},{id:58,name:"List",parentId:6},{id:59,name:"Set",parentId:6},{id:60,name:"Map",parentId:6},{id:2,name:"计算机网络",parentId:0}]),f=[{id:"plain",name:"纯文本",md:`集合分为两大分支：Collection 与 Map。

Collection 又分为 List 和 Set。`},{id:"heading",name:"标题层级",md:`# 一级标题

## 二级标题

正文一段。

### 三级标题

再一段。

## 第二个二级

结尾。`},{id:"bold-list",name:"列表 + 粗体",md:`Collection派生了三个子接口：

- **List:** List代表了有序可重复集合，可直接根据元素的索引来访问
- **Set:** Set代表无序不可重复集合，只能根据元素本身来访问
- **Queue:** Queue是队列集合`},{id:"bold-list-tight",name:"粗体紧跟文字（无空格）",md:`- **List：**List代表了有序可重复集合
- **Set：**Set代表无序不可重复集合`},{id:"link",name:"链接",md:`正文里带一个普通链接：

[MDN](https://developer.mozilla.org)

带一个目录引用：

见 [List](/app/learn?category=58)`},{id:"file",name:"附件",md:`带三个附件：

[天源迪科-电渠资源台账.xlsx](/api/files/u/6/contents/abc123/天源迪科-电渠资源台账.xlsx)

[说明文档.md](/api/files/u/6/contents/abc123/说明文档.md)

[报告.pdf](/api/files/u/6/contents/abc123/报告.pdf)

普通链接不受影响：[MDN](https://developer.mozilla.org)`},{id:"table",name:"表格",md:`| 集合 | 有序 | 可重复 |
| --- | --- | --- |
| List | 是 | 是 |
| Set | 否 | 否 |`},{id:"code",name:"代码块",md:"```java\nList<String> list = new ArrayList<>();\n```"},{id:"mermaid",name:"mermaid 图",md:`字节码与跨平台机制：

\`\`\`mermaid
graph LR
    A[Java 源文件 .java] -->|javac 编译| B[字节码 .class]
    B -->|JVM on Windows| C[Windows 运行]
    B -->|JVM on Linux| D[Linux 运行]
    B -->|JVM on macOS| E[macOS 运行]
\`\`\`

图下面就是源码，可以直接改。`},{id:"mermaid-class",name:"mermaid 类图",md:`集合框架里 List 的位置：

\`\`\`mermaid
classDiagram
    class Iterable["Iterable（迭代器）"] {
        <<interface>>
    }
    class Collection["Collection（单列集合）"] {
        <<interface>>
    }
    class List["List（有序,可重复）"] {
        <<interface>>
        +add(E e) boolean
        +remove(Object o) boolean
    }
    class ArrayList["ArrayList（数组实现）"]
    class LinkedList["LinkedList（链表实现）"]
    Iterable <|-- Collection : 继承
    Collection <|-- List : 继承
    List <|.. ArrayList : 实现
    List <|.. LinkedList : 实现
    classDef iface fill:#F8D7DA,stroke:#C77C8A,color:#2b2b2b
    classDef impl fill:#D6E4F7,stroke:#6C8EBF,color:#2b2b2b
    cssClass "Iterable,Collection,List" iface
    cssClass "ArrayList,LinkedList" impl
\`\`\`

图下面就是源码，可以直接改。`}],y=f.find(n=>n.id===new URLSearchParams(window.location.search).get("preset"))||f[0],s=i(y.md),m=i(!0),u=i(0),l=i(null),_=i([]),k=i(null);function x(n){var e;(e=k.value)==null||e.scrollToHeading(n)}function E(n){s.value=n.md,u.value++,l.value=null}async function C(){for(let n=0;n<40;n++)await N(),await new Promise(e=>setTimeout(e,50))}async function S(){const n=s.value;u.value++,await C();const e=s.value;u.value++,await C();const o=s.value;if(e===o){l.value={ok:!0,detail:""};return}l.value={ok:!1,detail:[`【第一次存下来的】
${n}`,`【重新打开后再存】
${e}`,`【再打开一次】
${o}`].join(`

`)}}async function w(){await R(s.value)&&j.success("已复制")}return(n,e)=>{const o=T("el-button");return r(),d("div",F,[a("header",J,[e[4]||(e[4]=a("h1",null,"编辑器实验台",-1)),e[5]||(e[5]=a("span",{class:"lab__note"},"编辑器行为的自测页：改完编辑器相关功能来这里跑一遍。免登录、不落库。",-1)),c(o,{size:"small",onClick:e[0]||(e[0]=t=>m.value=!m.value)},{default:p(()=>[b(v(m.value?"简洁模式":"完整模式"),1)]),_:1})]),a("section",H,[e[6]||(e[6]=a("span",{class:"lab__label"},"预设内容",-1)),(r(),d(M,null,A(f,t=>c(o,{key:t.id,size:"small",text:"",onClick:Z=>E(t)},{default:p(()=>[b(v(t.name),1)]),_:2},1032,["onClick"])),64))]),(r(),I(O,{key:u.value,ref_key:"editorRef",ref:k,modelValue:s.value,"onUpdate:modelValue":e[1]||(e[1]=t=>s.value=t),"show-toolbar":m.value,"category-tree":D(g),onOutline:e[2]||(e[2]=t=>_.value=t)},null,8,["modelValue","show-toolbar","category-tree"])),a("section",U,[a("div",G,[e[9]||(e[9]=a("span",{class:"lab__label"},"存下来的 markdown",-1)),c(o,{size:"small",text:"",onClick:S},{default:p(()=>[...e[7]||(e[7]=[b("往返自检",-1)])]),_:1}),c(o,{size:"small",text:"",onClick:w},{default:p(()=>[...e[8]||(e[8]=[b("复制",-1)])]),_:1})]),V(a("textarea",{"onUpdate:modelValue":e[3]||(e[3]=t=>s.value=t),class:"lab__ta",spellcheck:"false"},null,512),[[h,s.value]])]),_.value.length?(r(),d("section",Q,[e[10]||(e[10]=a("div",{class:"lab__label"},"大纲（点一条跳过去；鼠标移上去有工具条；标题左边的箭头折的是大纲自己那一支）",-1)),c(z,{items:_.value,onNavigate:x},null,8,["items"])])):L("",!0),l.value?(r(),d("section",{key:1,class:B(["lab__check kb-verdict",l.value.ok?"is-good":"is-bad"])},[a("p",W,v(l.value.ok?"往返稳定":"往返不稳定 —— 这就是刷新后走样的那种内容"),1),l.value.ok?L("",!0):(r(),d("pre",q,v(l.value.detail),1))],2)):L("",!0)])}}}),me=$(K,[["__scopeId","data-v-2cda0030"]]);export{me as default};
