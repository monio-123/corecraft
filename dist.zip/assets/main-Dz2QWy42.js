import{b as r,r as o}from"./bootstrap-DOpRJS_0.js";import"./vendor-core-KLT20Xze.js";r(o);
