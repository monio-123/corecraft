import{$ as o,a0 as n}from"./mermaid.core-DF5KPFME.js";const t=(r,a)=>o.lang.round(n.parse(r)[a]);export{t as c};
